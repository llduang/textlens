				import worker, * as OTHER_EXPORTS from "/home/z/my-project/.wrangler/tmp/pages-OSIXn4/functionsWorker-0.03907612265914562.mjs";
				import * as __MIDDLEWARE_0__ from "/home/z/my-project/node_modules/wrangler/templates/middleware/middleware-ensure-req-body-drained.ts";
import * as __MIDDLEWARE_1__ from "/home/z/my-project/node_modules/wrangler/templates/middleware/middleware-miniflare3-json-error.ts";

				export * from "/home/z/my-project/.wrangler/tmp/pages-OSIXn4/functionsWorker-0.03907612265914562.mjs";
				const MIDDLEWARE_TEST_INJECT = "__INJECT_FOR_TESTING_WRANGLER_MIDDLEWARE__";
				export const __INTERNAL_WRANGLER_MIDDLEWARE__ = [
					
					__MIDDLEWARE_0__.default,__MIDDLEWARE_1__.default
				]
				export default worker;