import { onRequestPost as __api_recognize_index_ts_onRequestPost } from "/home/z/my-project/functions/api/recognize/index.ts"

export const routes = [
    {
      routePath: "/api/recognize",
      mountPath: "/api/recognize",
      method: "POST",
      middlewares: [],
      modules: [__api_recognize_index_ts_onRequestPost],
    },
  ]